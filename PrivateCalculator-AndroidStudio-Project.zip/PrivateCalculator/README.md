# Private Calculator — Android Studio project

Features:
- Calculator screen with basic arithmetic.
- PIN setup (4–8 digits) and fingerprint unlock where the device supports strong biometrics.
- Imports photos, videos and documents through Android's system file picker.
- Encrypts imported content using AES-256-GCM with a key held in Android Keystore.
- Stores encrypted files in app-private internal storage; no broad storage permission is requested.
- Delete items from the vault.

## Build APK
1. Install Android Studio (a current stable version) and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync to finish.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show the APK location (usually `app/build/outputs/apk/debug/app-debug.apk`).

## Important notes
- This is a starter project; it has not been compiled or tested on a physical device in this environment.
- Fingerprint unlock is offered only when Android reports strong biometric authentication as available. PIN remains available as a fallback.
- Imported files are copied into the encrypted vault. The original files in Gallery/Downloads are NOT deleted; delete originals yourself only after verifying that the vault copy is present.
- Uninstalling the app or clearing its data removes the vault and its encryption key. Export/backup your files before uninstalling or resetting the phone.
- Keep your PIN safe. There is no PIN recovery flow in this starter build.
