package com.privatecalculator.vault

import android.content.Context
import android.net.Uri
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.io.File
import java.io.FileOutputStream
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

object VaultCrypto {
    private const val KEY_ALIAS = "private_calculator_vault_key"
    private const val TRANSFORMATION = "AES/GCM/NoPadding"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(
            KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
         .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
         .setRandomizedEncryptionRequired(true).build())
        return generator.generateKey()
    }

    fun encrypt(context: Context, uri: Uri, output: File) {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val iv = cipher.iv
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Cannot open selected file" }
            FileOutputStream(output).use { fileOut ->
                fileOut.write(iv.size)
                fileOut.write(iv)
                javax.crypto.CipherOutputStream(fileOut, cipher).use { encrypted ->
                    input.copyTo(encrypted)
                }
            }
        }
    }

    fun decryptToCache(input: File, output: File) {
        input.inputStream().use { fileIn ->
            val ivLength = fileIn.read()
            require(ivLength in 12..16) { "Invalid encrypted file" }
            val iv = ByteArray(ivLength)
            require(fileIn.read(iv) == ivLength) { "Invalid encrypted file" }
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
            javax.crypto.CipherInputStream(fileIn, cipher).use { decrypted ->
                FileOutputStream(output).use { decrypted.copyTo(it) }
            }
        }
    }
}
