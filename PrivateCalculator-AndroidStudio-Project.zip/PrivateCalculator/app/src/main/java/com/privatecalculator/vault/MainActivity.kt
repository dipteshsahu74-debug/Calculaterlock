package com.privatecalculator.vault

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import java.io.File
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("vault_settings", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private val pickFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) saveSelectedFile(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showGate()
    }

    private fun setupRoot() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFF121212.toInt())
        }
        setContentView(root)
    }

    private fun text(value: String, size: Float = 16f): TextView =
        TextView(this).apply {
            text = value; textSize = size; setTextColor(0xFFF4F0FA.toInt())
            setPadding(0, 10, 0, 10)
        }

    private fun field(hintText: String): EditText = EditText(this).apply {
        hint = hintText; setSingleLine(true); inputType =  numberPassword()
        setTextColor(0xFFFFFFFF.toInt()); setHintTextColor(0xFFBDB5C8.toInt())
        setPadding(18, 12, 18, 12)
        setBackgroundColor(0xFF29252F.toInt())
    }

    private fun numberPassword() = android.text.InputType.TYPE_CLASS_NUMBER or
            android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD

    private fun button(label: String, action: () -> Unit): Button =
        Button(this).apply { text = label; setOnClickListener { action() } }

    private fun showGate() {
        setupRoot()
        root.gravity = Gravity.CENTER_HORIZONTAL
        root.addView(text("◈  PRIVATE CALCULATOR", 24f))
        root.addView(text(if (prefs.contains("pin_hash")) "Enter your PIN" else "Create a 4–8 digit PIN"))
        val pin = field("PIN")
        root.addView(pin, matchWidth())
        root.addView(button(if (prefs.contains("pin_hash")) "Unlock" else "Create PIN") {
            val value = pin.text.toString()
            if (value.length !in 4..8 || value.any { !it.isDigit() }) {
                toast("Enter a 4–8 digit PIN"); return@button
            }
            if (!prefs.contains("pin_hash")) {
                val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
                prefs.edit().putString("pin_salt", salt.joinToString("") { "%02x".format(it) })
                    .putString("pin_hash", hashPin(value, salt)).apply()
                showGate()
            } else {
                val salt = hexToBytes(prefs.getString("pin_salt", "") ?: "")
                if (hashPin(value, salt) == prefs.getString("pin_hash", null)) showVault()
                else toast("Incorrect PIN")
            }
        })
        if (prefs.contains("pin_hash") && biometricAvailable()) {
            root.addView(button("Unlock with fingerprint") { promptBiometric() })
        }
        root.addView(text("Your files stay encrypted in this app's private storage.", 13f))
    }

    private fun hashPin(pin: String, salt: ByteArray): String {
        val spec = PBEKeySpec(pin.toCharArray(), salt, 120_000, 256)
        val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun hexToBytes(s: String): ByteArray = s.chunked(2).map { it.toInt(16).toByte() }.toByteArray()

    private fun biometricAvailable(): Boolean =
        BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) ==
                BiometricManager.BIOMETRIC_SUCCESS

    private fun promptBiometric() {
        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    showVault()
                }
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    toast(errString.toString())
                }
            })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Private Calculator")
            .setSubtitle("Confirm your fingerprint to unlock")
            .setNegativeButtonText("Use PIN")
            .build()
        prompt.authenticate(info)
    }

    private fun showVault() {
        setupRoot()
        root.addView(text("PRIVATE CALCULATOR", 23f))
        root.addView(text("Your private files are encrypted on this device.", 13f))
        root.addView(button("＋  Hide photos, videos or files") {
            pickFile.launch(arrayOf("image/*", "video/*", "application/pdf", "*/*"))
        })
        root.addView(button("Open Calculator") { showCalculator() })
        root.addView(button("Lock now") { showGate() })
        root.addView(text("YOUR VAULT", 18f))
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)
        val files = vaultDir().listFiles()?.sortedBy { it.name } ?: emptyList()
        if (files.isEmpty()) list.addView(text("No hidden files yet."))
        files.forEach { file ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val label = TextView(this).apply {
                text = file.name.substringAfter("__", "Encrypted file")
                setTextColor(0xFFF4F0FA.toInt()); textSize = 14f
            }
            row.addView(label, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(button("Delete") {
                file.delete(); showVault()
            })
            list.addView(row)
        }
    }

    private fun saveSelectedFile(uri: Uri) {
        try {
            val name = "vault_${System.currentTimeMillis()}__" +
                    (contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
                        ?.use { c -> if (c.moveToFirst()) c.getString(0) else "file" } ?: "file")
                        .replace(Regex("[^A-Za-z0-9._-]"), "_")
            VaultCrypto.encrypt(this, uri, File(vaultDir(), name))
            toast("File encrypted and added to your vault")
            showVault()
        } catch (e: Exception) {
            toast("Could not hide file: ${e.message ?: "unknown error"}")
        }
    }

    private fun vaultDir() = File(filesDir, "encrypted_vault").apply { mkdirs() }

    private fun showCalculator() {
        setupRoot()
        root.addView(text("CALCULATOR", 22f))
        val display = TextView(this).apply {
            text = "0"; textSize = 34f; gravity = Gravity.END
            setTextColor(0xFFFFFFFF.toInt()); setPadding(8, 24, 8, 24)
        }
        root.addView(display, matchWidth())
        var current = "0"
        var stored: Double? = null
        var op: String? = null
        var fresh = false
        val grid = arrayOf(
            arrayOf("AC", "±", "%", "÷"),
            arrayOf("7", "8", "9", "×"),
            arrayOf("4", "5", "6", "−"),
            arrayOf("1", "2", "3", "+"),
            arrayOf("0", ".", "⌫", "=")
        )
        grid.forEach { line ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            line.forEach { key ->
                row.addView(button(key) {
                    when (key) {
                        "AC" -> { current = "0"; stored = null; op = null }
                        "±" -> current = (-current.toDouble()).toString()
                        "%" -> current = (current.toDouble() / 100).toString()
                        "⌫" -> current = if (current.length > 1) current.dropLast(1) else "0"
                        "+", "−", "×", "÷" -> { stored = current.toDouble(); op = key; fresh = true }
                        "=" -> {
                            val a = stored; val b = current.toDouble()
                            if (a != null && op != null) {
                                val result = when (op) {
                                    "+" -> a + b; "−" -> a - b; "×" -> a * b
                                    else -> if (b == 0.0) Double.NaN else a / b
                                }
                                current = if (result.isNaN() || result.isInfinite()) "Error" else result.toString()
                                stored = null; op = null; fresh = true
                            }
                        }
                        else -> {
                            if (fresh || current == "Error") current = if (key == ".") "0." else key
                            else if (key == "." && current.contains(".")) Unit
                            else current = if (current == "0" && key != ".") key else current + key
                            fresh = false
                        }
                    }
                    display.text = current
                }, LinearLayout.LayoutParams(0, 58, 1f))
            }
            root.addView(row)
        }
        root.addView(button("Back to Vault") { showVault() })
    }

    private fun matchWidth() = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 12 }
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
